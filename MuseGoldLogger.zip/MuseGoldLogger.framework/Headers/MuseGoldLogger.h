//
//  MuseGoldLogger.h
//  MuseGoldLogger
//
//  Created by Vinay Ganesh on 3/2/19.
//  Copyright © 2019 Vinay Ganesh. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MuseGoldLogger.
FOUNDATION_EXPORT double MuseGoldLoggerVersionNumber;

//! Project version string for MuseGoldLogger.
FOUNDATION_EXPORT const unsigned char MuseGoldLoggerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MuseGoldLogger/PublicHeader.h>


